const button = document.getElementById("myButton");

button.addEventListener("click", function() {
  if (this.style.backgroundColor === "blue") {
    this.style.backgroundColor = "ddd";
  } else {
    this.style.backgroundColor = "blue";
  }
});
